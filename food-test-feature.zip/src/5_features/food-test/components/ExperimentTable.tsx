import { LabStage } from './LabStage';
import { TypedText } from './TypedText';
import type { RunStatus } from '../hooks/useExperimentRunner';
import type { SceneState } from '../lab/useLab';
import type { Experiment, Outcome } from '../types';

interface ExperimentTableProps {
  experiment: Experiment;
  outcome: Outcome;
  scene: SceneState;
  currentIndex: number;
  completed: number;
  status: RunStatus;
}

const head = 'border border-border bg-[#181818] px-5 py-3 text-left text-sm font-semibold text-white';
const cell = 'border border-border px-5 py-4 align-top transition-colors duration-300';

/** Lab-notebook layout: procedure and animation | observations | deductions. */
export function ExperimentTable({ experiment, outcome, scene, currentIndex, completed, status }: ExperimentTableProps) {
  const { steps } = experiment;
  const deduction = experiment.deduction[outcome];

  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[980px] table-fixed border-collapse text-left">
        <caption className="sr-only">{experiment.title}: procedure, observations and deductions</caption>
        <colgroup>
          <col className="w-[46%]" />
          <col className="w-[30%]" />
          <col className="w-[24%]" />
        </colgroup>
        <thead>
          <tr>
            <th scope="col" className={head}>Procedure and animation</th>
            <th scope="col" className={head}>Observations</th>
            <th scope="col" className={head}>Deductions</th>
          </tr>
        </thead>
        <tbody>
          {steps.map((step, i) => {
            const active = i === currentIndex;
            const done = i < completed;
            const bg = active ? 'bg-[#212121]' : 'bg-[#101010]';
            return (
              <tr key={step.id} aria-current={active ? 'step' : undefined}>
                <td className={`${cell} ${bg}`}>
                  <div className="flex items-start gap-4">
                    <span
                      className={`mt-0.5 grid h-7 w-7 shrink-0 place-items-center border border-border text-sm font-semibold tabular-nums ${
                        active ? 'bg-white text-black' : done ? 'bg-[#2a2a2a] text-white' : 'text-white/60'
                      }`}
                    >
                      {i + 1}
                    </span>
                    <p className={`text-[15px] leading-relaxed ${active ? 'font-medium text-white' : done ? 'text-white/90' : 'text-white/70'}`}>
                      {step.procedure}
                    </p>
                  </div>
                </td>
                <td className={`${cell} ${bg}`}>
                  <div aria-live="polite" className="text-[15px] leading-relaxed">
                    {done ? (
                      <TypedText text={step.observation[outcome]} />
                    ) : active ? (
                      <span className="text-white/60">Observing…</span>
                    ) : (
                      <span className="text-white/35">Not yet recorded</span>
                    )}
                  </div>
                </td>
                {i === 0 && (
                  <td rowSpan={steps.length + 1} className={`${cell} bg-[#101010]`}>
                    <div className="sticky top-6 space-y-4">
                      {status === 'done' ? (
                        <>
                          <p className="border border-border bg-white px-4 py-3 text-base font-bold text-black">
                            <TypedText text={deduction.result} />
                          </p>
                          <p className="text-sm leading-relaxed text-white/80">
                            <TypedText text={deduction.explanation} speed={14} />
                          </p>
                        </>
                      ) : (
                        <p className="text-sm leading-relaxed text-white/45">The deduction is recorded once the test is complete.</p>
                      )}
                    </div>
                  </td>
                )}
              </tr>
            );
          })}
          <tr>
            <td className={`${cell} bg-[#101010] p-4`}>
              <LabStage scene={scene} />
            </td>
            <td className={`${cell} bg-[#101010]`}>
              <div className="space-y-4">
                <p className="text-sm font-semibold text-white">{status === 'done' ? 'Finished' : `Step ${Math.max(currentIndex + 1, 1)} of ${steps.length}`}</p>
                <p aria-live="polite" className="text-[15px] leading-relaxed text-white/80">
                  {scene.caption}
                </p>
                <ol aria-hidden="true" className="flex gap-1.5">
                  {steps.map((step, i) => (
                    <li
                      key={step.id}
                      className={`h-2 flex-1 border border-border ${i < completed ? 'bg-white' : i === currentIndex ? 'bg-white/40' : 'bg-transparent'}`}
                    />
                  ))}
                </ol>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}
